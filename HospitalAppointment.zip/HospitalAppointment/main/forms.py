from django import forms
from django.contrib.auth.models import User

HOSPITAL_NAMES=[
    ('Sangamitra','Sangamitra'),
    ('SaiDeeraj','Deeraj Nursing Home'),
    ('Bethun','Bethun Nursing Home'),
    ('Prasad','Prasad Multi Speciality Hospital'),
    ('Ravi','Ravi Mother & Child Hospital'),
    ('Anish','Anish Kidney Center'),
    ('sundhara','sundhara Raja Nursing Home'),
    ('APIC','APIC Hospital'),
    ('kims','Kims Hospital'),
    ('Rims','Rims hospital')
    ]
DOCTOR_NAMES= [
    ('Srinivas', 'Srinivas-Cardiologist'),
    ('Satya', 'Satya-ENT'),
    ('Prasad', 'Prasad-GeneralPhysician'),
    ('Sita','Sita-Gynacologist')
    ]
class BookAppointment(forms.Form):
    name = forms.CharField(label="Name",max_length=200)
    #Male = forms.BooleanField()
    #Female = forms.BooleanField()
    Gender = forms.CharField(label="Gender(M/F)",max_length=1)
    Hospital = forms.CharField(label='Hospital', widget=forms.Select(choices=HOSPITAL_NAMES))
    print(Hospital)
    doctor = forms.CharField(label='Doctor', widget=forms.Select(choices=DOCTOR_NAMES))
    issue = forms.CharField(label="Health Issue",max_length=500)
    

