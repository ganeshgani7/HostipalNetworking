from django.shortcuts import render,redirect
from django.contrib.auth import login, authenticate, logout
from .forms import RegisterForm

# Create your views here.
def register(response):
    print('123')
    if response.method== "POST":
        print('456')
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()
            return redirect("/home")
    else:
        form = RegisterForm()
    return render(response,"register/register.html",{"form":form})


#def login(request):
 #   pass
 #   print('456')
  #  if response.method=="POST":
   #     print('came')
    #    username = response.POST['Username']
     #   password = response.POST['Password']
      #  user = authenticate(response,username,password)
       # if user is not None:
        #    login(response,user)
         #   return redirect('/home')
        #else:
         #   return redirect('/login')

    #return render(response,'registration/login.html',{})



    

